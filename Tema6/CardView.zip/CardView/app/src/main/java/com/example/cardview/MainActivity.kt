package com.example.cardview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.slider.RangeSlider

class MainActivity : AppCompatActivity() {
    private lateinit var tvIngresos: TextView
    private lateinit var opcionSeleccionada: String
    private val incrementoDeIngresos = 100


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rangeSlider = findViewById<RangeSlider>(R.id.rsEdad)
        val tvAnos = findViewById<TextView>(R.id.tvAnos)
        val btnMayor = findViewById<FloatingActionButton>(R.id.btnMayor)
        val btnMenor = findViewById<FloatingActionButton>(R.id.btnMenor)
        tvIngresos = findViewById(R.id.tvIngresos)

        val cardView1 = findViewById<CardView>(R.id.cardView1)
        val cardView2 = findViewById<CardView>(R.id.cardView2)
        val btnAceptar = findViewById<Button>(R.id.btnAceptar)

        rangeSlider.addOnChangeListener { slider, value, fromUser ->
            tvAnos.text = "${value.toInt()} años"
        }
        btnMayor.setOnClickListener {
            aumentarIngresos()
        }
        btnMenor.setOnClickListener {
            disminuirIngresos()
        }

        cardView1.setOnClickListener {
            handleCardViewClick(cardView1)
        }
        cardView2.setOnClickListener {
            handleCardViewClick(cardView2)
        }

        btnAceptar.setOnClickListener {
            val intent = Intent(this, Resultado::class.java)
            val ingresos = tvIngresos.text.toString().toInt()
            val edad = rangeSlider.values[0].toInt()
            intent.putExtra("ingresos",ingresos)
            intent.putExtra("edad",edad)
            intent.putExtra("opcionSeleccionada",opcionSeleccionada)

            startActivity(intent)
        }
    }

    private fun aumentarIngresos() {
        val valorActual = tvIngresos.text.toString().toInt()
        val nuevoValor = valorActual + incrementoDeIngresos
// Asegura que el nuevo valor no exceda el límite superior
        if (nuevoValor <= Int.MAX_VALUE) {
            tvIngresos.text = nuevoValor.toString()
        }
    }
    private fun disminuirIngresos() {
        val valorActual = tvIngresos.text.toString().toInt()
        val nuevoValor = valorActual - incrementoDeIngresos
// Asegura que el nuevo valor no sea inferior a cero
        if (nuevoValor >= 0) {
            tvIngresos.text = nuevoValor.toString()

        }
    }

    private fun handleCardViewClick(cardView: CardView) {
        when (cardView.id) {
            R.id.cardView1 -> {
                println("Se ha pulsado cardview1")
                Log.d("CardView", "Has pulsado el cardview1")
                opcionSeleccionada = " cardview1"
            }

            R.id.cardView2 -> {
                println("Se ha pulsado cardview2")
                Log.d("CardView", "Has pulsado el cardview2")
                opcionSeleccionada = " cardview2"
            }

            R.id.cardView3 -> {
                println("Se ha pulsado cardview3")
                Log.d("CardView", "Has pulsado el cardview3")
                opcionSeleccionada = " cardview3"
            }
        }
    }
}