package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Calculadora : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        val tvResult=findViewById<TextView>(R.id.tvResult)
        val res= intent.extras?.getDouble("EXTRA_RESULTADO")
        tvResult.text = "Resultado: $res"
    }
}