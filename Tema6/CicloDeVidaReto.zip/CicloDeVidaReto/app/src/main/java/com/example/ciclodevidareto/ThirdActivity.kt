package com.example.ciclodevidareto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        val tvResult=findViewById<TextView>(R.id.tvmensaje)
        val apellido:String = intent.extras?.getString("EXTRA_APELLIDO").orEmpty()
        val curso:String = intent.extras?.getString("EXTRA_curso").orEmpty()
        val asignatura:String = intent.extras?.getString("EXTRA_asignatura").orEmpty()
        val nota:String = intent.extras?.getString("EXTRA_notas").orEmpty()
        val btn =findViewById<AppCompatButton>(R.id.btn)
        tvResult.text = "Datos: \nApellido: $apellido \n" +
                "Curso: $curso\nAsignatura: $asignatura\nNota: $nota"


        btn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}