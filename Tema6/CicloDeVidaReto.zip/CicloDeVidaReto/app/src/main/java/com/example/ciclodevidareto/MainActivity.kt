package com.example.ciclodevidareto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnNombre = findViewById<AppCompatButton>(R.id.btnStart)
        val btnDatos = findViewById<AppCompatButton>(R.id.btn2)
        val etName = findViewById<AppCompatEditText>(R.id.etName)
        val etApellido = findViewById<AppCompatEditText>(R.id.etApellido)
        val etCurso = findViewById<AppCompatEditText>(R.id.etCurso)
        val etAsignatura = findViewById<AppCompatEditText>(R.id.etAsignatura)
        val etNota = findViewById<AppCompatEditText>(R.id.etNota)


        btnNombre.setOnClickListener {
            val name = etName.text.toString()
            if (name.isNotEmpty()) {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("EXTRA_NAME", name)
                startActivity(intent)
            }
        }

        btnDatos.setOnClickListener{
            val apellido = etApellido.text.toString()
            val curso = etCurso.text.toString()
            val asignatura = etAsignatura.text.toString()
            val notas = etNota.text.toString()
            if (apellido.isNotEmpty()&&curso.isNotEmpty()&&
                asignatura.isNotEmpty() && notas.isNotEmpty()) {
                val intent = Intent(this, ThirdActivity::class.java)
                intent.putExtra("EXTRA_APELLIDO", apellido)
                intent.putExtra("EXTRA_curso", curso)
                intent.putExtra("EXTRA_asignatura", asignatura)
                intent.putExtra("EXTRA_notas", notas)
                startActivity(intent)
            }
        }
    }
}