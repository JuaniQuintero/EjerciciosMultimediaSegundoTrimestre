package com.example.androidmaster
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.slider.RangeSlider

class Activity1 : AppCompatActivity() {
    private lateinit var tvPeso: TextView
    private lateinit var tvEdad: TextView
    private val incrementoEdad = 1
    private val incrementoPeso = 1
    private lateinit var opcionSeleccionada: String
    private var peso: Int = 0  // Variable para almacenar el peso

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_1)

        tvEdad = findViewById<TextView>(R.id.tvIngresos)
        val rangeSlider = findViewById<RangeSlider>(R.id.rsAltura)
        val rsAltura = findViewById<RangeSlider>(R.id.rsAltura)
        val btnMayor = findViewById<FloatingActionButton>(R.id.btnMayor)
        val btnMenor = findViewById<FloatingActionButton>(R.id.btnMenor)
        val btnMayor2 = findViewById<FloatingActionButton>(R.id.btnMayor2)
        val btnMenor2 = findViewById<FloatingActionButton>(R.id.btnMenor2)
        tvPeso = findViewById(R.id.tvPeso)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val cardView1: CardView = findViewById<CardView>(R.id.cardView1)
        val cardView2: CardView = findViewById<CardView>(R.id.cardView2)
        val tvAltura = findViewById<TextView>(R.id.tvAltura)

        rangeSlider.addOnChangeListener { slider, value, fromUser ->
            // Actualiza el texto del TextView con el valor seleccionado
            tvAltura.text = "${value.toInt()} cm"
        }

        btnMayor.setOnClickListener {
            aumentoPeso()
        }

        btnMenor.setOnClickListener {
            disminuirPeso()
        }

        btnMayor2.setOnClickListener {
            aumentoEdad()
        }

        btnMenor2.setOnClickListener {
            disminuirEdad()
        }

        cardView1.setOnClickListener {
            handleCardViewClick(cardView1)
        }

        cardView2.setOnClickListener {
            handleCardViewClick(cardView2)
        }

        btnCalcular.setOnClickListener {
            // Verifica si opcionSeleccionada está inicializada antes de usarla
            if (::opcionSeleccionada.isInitialized) {
                // Obtener los valores que necesitas, por ejemplo, la edad y la altura
                val edad = tvEdad.text.toString().toInt()
                val altura = rangeSlider.values[0].toInt()

                // Guardar el peso
                peso = tvPeso.text.toString().toInt()

                // Calcular el IMC
                val imc = calcularIMC(peso, altura)

                // Obtener la clasificación
                val clasif = clasificacion(imc)

                // Crear un Intent para iniciar la SegundaActividad
                val intent = Intent(this, SegundaActividad::class.java)
                intent.putExtra("IMC", imc)
                intent.putExtra("Clasificacion", clasif)
                startActivity(intent)
            }
        }
    }

    private fun aumentoPeso() {
        val valorActual = tvPeso.text.toString().toInt()
        val nuevoValor = valorActual + incrementoPeso

        // Asegura que el nuevo valor no exceda el límite superior
        if (nuevoValor <= Int.MAX_VALUE) {
            tvPeso.text = nuevoValor.toString()
        }
    }

    private fun aumentoEdad() {
        val valorActual = tvEdad.text.toString().toInt()
        val nuevoValor = valorActual + incrementoEdad

        // Asegura que el nuevo valor no exceda el límite superior
        if (nuevoValor <= Int.MAX_VALUE) {
            tvEdad.text = nuevoValor.toString()
        }
    }

    private fun disminuirEdad() {
        val valorActual = tvEdad.text.toString().toInt()
        val nuevoValor = valorActual - incrementoEdad

        // Asegura que el nuevo valor no sea inferior a cero
        if (nuevoValor >= 0) {
            tvEdad.text = nuevoValor.toString()
        }
    }

    private fun disminuirPeso() {
        val valorActual = tvPeso.text.toString().toInt()
        val nuevoValor = valorActual - incrementoPeso

        // Asegura que el nuevo valor no sea inferior a cero
        if (nuevoValor >= 0) {
            tvPeso.text = nuevoValor.toString()
        }
    }

    private fun handleCardViewClick(cardView: CardView) {
        when (cardView.id) {
            R.id.cardView1 -> {
                println("Se ha pulsado Hombre")
                Log.d("CardView", "Eres Hombre")
                opcionSeleccionada = " Hombre"
            }

            R.id.cardView2 -> {
                println("Se ha pulsado Mujer")
                Log.d("CardView", "Eres Mujer")
                opcionSeleccionada = "Mujer"
            }
        }
    }

    private fun calcularIMC(peso: Int, altura: Int): Double {
        // Fórmula del IMC: peso (kg) / (altura (m))^2
        val alturaMetros = altura / 100.0
        return peso / (alturaMetros * alturaMetros)
    }

    private fun clasificacion(imc: Double): String {
        // Lógica para determinar la clasificación según el IMC
        // Retorna la clasificación
        return when {
            imc < 18.5 -> "Bajo peso"
            imc < 24.9 -> "Normal"
            imc < 29.9 -> "Sobrepeso"
            else -> "Obeso"
        }
    }
}
