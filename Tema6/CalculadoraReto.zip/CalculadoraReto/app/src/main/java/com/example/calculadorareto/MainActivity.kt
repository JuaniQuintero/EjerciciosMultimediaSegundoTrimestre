package com.example.calculadorareto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var num1 = 0.0f
        var num2 = 0.0f
        var operacion = ""
        var tvResultado:TextView = findViewById(R.id.tvResultado)

        val btnAc:Button = findViewById(R.id.btAC)
        val btnCambio:Button = findViewById(R.id.btCambio)

        val btnMulti:Button = findViewById(R.id.btMulti)
        val btnDiv:Button = findViewById(R.id.btDiv)
        val btnMas:Button = findViewById(R.id.btMas)
        val btnMenos:Button = findViewById(R.id.btMenos)
        val btnPorcentaje:Button = findViewById(R.id.btPorc)

        val btnIgual:Button =  findViewById(R.id.btIgual)
        val btnPunto:Button =   findViewById(R.id.btPunto)

        val btn0:Button = findViewById(R.id.bt0)
        val btn1:Button = findViewById(R.id.bt1)
        val btn2:Button = findViewById(R.id.bt2)
        val btn3:Button = findViewById(R.id.bt3)
        val btn4:Button = findViewById(R.id.bt4)
        val btn5:Button = findViewById(R.id.bt5)
        val btn6:Button = findViewById(R.id.bt6)
        val btn7:Button = findViewById(R.id.bt7)
        val btn8:Button = findViewById(R.id.bt8)
        val btn9:Button = findViewById(R.id.bt9)


        btnAc.setOnClickListener {
            tvResultado.text = "0"
            num1 = 0.0f
            num2 = 0.0f
            operacion = ""
        }
        btnPunto.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "0"
            }else if (!tvResultado.text.toString().contains(".")){
                (tvResultado.text.toString()+".").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btnCambio.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            tvResultado.text = (num1*-1).toString()
        }


        btnPorcentaje.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            operacion = "%"
            tvResultado.text = "0"
            num2 = num1
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }
        btnMulti.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            operacion = "*"
            tvResultado.text = "0"
            num2 = num1
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }
        btnDiv.setOnClickListener{
            num1 = tvResultado.text.toString().toFloat()
            operacion = "/"
            tvResultado.text = "0"
            num2 = num1

        }

        btnMas.setOnClickListener{
            num1 = tvResultado.text.toString().toFloat()
            operacion = "+"
            tvResultado.text = "0"
            num2 = num1
        }
        btnMenos.setOnClickListener{
            num1 = tvResultado.text.toString().toFloat()
            operacion = "-"
            tvResultado.text = "0"
            num2 = num1
        }
        btnIgual.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var res = 0.0f
            Log.d("Operacion",operacion)
            if(operacion == "*"){
                Log.d("Numero1",num1.toString())
                Log.d("Numero2",num2.toString())
                res = num1*num2
                tvResultado.text = res.toString()
            }else if (operacion == "/"){
                if(num1 == 0.0f){
                    tvResultado.text = "0"
                    Toast.makeText(this,"OPERACIÓN NO VALIDA",Toast.LENGTH_LONG).show()
                }else{
                    res = num2 / num1
                    tvResultado.text = res.toString()
                }
            }else if(operacion == "+"){
                res = num1 + num2
                tvResultado.text = res.toString()
            }else if(operacion == "-"){
                res = num2-num1
                tvResultado.text = res.toString()
            }else if(operacion == "%"){
                res = num2*num1/100
                tvResultado.text = res.toString()
            }
        }

        btn0.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "0"
            }else{
                (tvResultado.text.toString()+"0").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn1.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "1"
            }else{
                (tvResultado.text.toString()+"1").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn2.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "2"
            }else{
                (tvResultado.text.toString()+"2").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn3.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "3"
            }else{
                (tvResultado.text.toString()+"3").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn4.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "4"
            }else{
                (tvResultado.text.toString()+"4").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn5.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "5"
            }else{
                (tvResultado.text.toString()+"5").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn6.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "6"
            }else{
                (tvResultado.text.toString()+"6").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

        btn7.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "7"
            }else{
                (tvResultado.text.toString()+"7").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }


        btn8.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "8"
            }else{
                (tvResultado.text.toString()+"8").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }


        btn9.setOnClickListener {
            num1 = tvResultado.text.toString().toFloat()
            var texto = tvResultado.text
            if(num1 == 0.0f){
                tvResultado.text = "9"
            }else{
                (tvResultado.text.toString()+"9").also { tvResultado.text = it }
            }
            Log.d("Numero1",num1.toString())
            Log.d("Numero2",num2.toString())
        }

    }

}