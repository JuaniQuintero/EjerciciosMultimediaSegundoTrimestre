package com.example.androidmaster

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SegundaActividad : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_actividad)

        // Obtener los datos del Intent
        val imc = intent.getDoubleExtra("IMC", 0.0)
        val clasificacion = intent.getStringExtra("Clasificacion")

        // Crear variables para las vistas
        val txtResVista = findViewById<TextView>(R.id.txtRes)
        val estadoVista = findViewById<TextView>(R.id.Estado)
        val puntVista = findViewById<TextView>(R.id.punt)
        val txtResultadoVista = findViewById<TextView>(R.id.txtResultado)

        // Mostrar los resultados en las vistas
        txtResVista.text = "Tu IMC es:"
        estadoVista.text = clasificacion
        puntVista.text = String.format("%.2f", imc)
        txtResultadoVista.text = obtenerResultado(clasificacion)
        val btnRecalcular = findViewById<Button>(R.id.btnRecalcular)
        // Configurar el OnClickListener para el botón Recalcular
        btnRecalcular.setOnClickListener {
            // Crear un Intent para volver a la Activity1
            val intent = Intent(this, Activity1::class.java)
            startActivity(intent)
            finish() // Esto asegura que la SegundaActividad se cierre después de iniciar la Activity1
        }
    }

    private fun obtenerResultado(clasificacion: String?): String {
        return when (clasificacion) {
            "Bajo peso" -> "Es importante asegurarse de tener una dieta balanceada."
            "Normal" -> "¡Felicidades! Mantén un estilo de vida saludable."
            "Sobrepeso" -> "Considera ajustar tu dieta y hacer ejercicio regularmente."
            "Obeso" -> "Se recomienda consultar a un profesional de la salud para un plan adecuado."
            else -> "Datos no válidos."
        }
    }
}




