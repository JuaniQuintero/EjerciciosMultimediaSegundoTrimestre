package com.example.retolayoutinflater;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.retolayoutinflater.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflar el diseño XML
        View rootView = LayoutInflater.from(this).inflate(R.layout.activity_main, null);

        // Obtener referencia al linearLayout (puedes usar el tipo de layout que estés utilizando)
        LinearLayout linearLayout = rootView.findViewById(R.id.linearLayoutContainer);

        // Crear un nuevo TextView dinámicamente
        TextView nuevoTextView = new TextView(this);
        nuevoTextView.setText("Hola, Alberto");

        EditText editText = new EditText(this);
        Button bt = new Button(this);
        bt.setText("VER TEXTO");

        TextView texto= new TextView(this);
        texto.setTextSize(24);


        // Agregar el nuevo TextView al contenedor
        linearLayout.addView(nuevoTextView);
        linearLayout.addView(editText);
        linearLayout.addView(bt);
        linearLayout.addView(texto);


        // Establecer la vista inflada en la actividad
        setContentView(rootView);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Acciones que se ejecutarán al hacer clic en el botón
                String textoIngresado = editText.getText().toString();
               texto.setText("El texto ingresado es: " + textoIngresado);

            }
        });


    }
}
