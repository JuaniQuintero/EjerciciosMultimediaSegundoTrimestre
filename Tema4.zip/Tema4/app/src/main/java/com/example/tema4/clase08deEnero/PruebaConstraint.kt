package com.example.tema4.clase08deEnero

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tema4.R

class PruebaConstraint : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prueba_constraint)
    }
}