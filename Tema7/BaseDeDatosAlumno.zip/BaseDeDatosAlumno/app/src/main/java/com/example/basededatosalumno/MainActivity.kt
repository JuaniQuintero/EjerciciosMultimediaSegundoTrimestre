package com.example.basededatosalumno

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var dataManager: DataManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        dataManager = DataManager(this)
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etApellido = findViewById<EditText>(R.id.etApellido)
        val etDni = findViewById<EditText>(R.id.etDni)
        val etEdad = findViewById<EditText>(R.id.etEdad)
        val etCurso = findViewById<EditText>(R.id.etCurso)
        val btnAgregar = findViewById<Button>(R.id.btnAgregar)
        val btnMostrar = findViewById<Button>(R.id.btnMostrar)
        val tvMuestraNombre = findViewById<TextView>(R.id.tvMuestraNombre)
        val btnEliminar = findViewById<Button>(R.id.btnEliminar)
        val btnActualizar = findViewById<Button>(R.id.btnModificar)

        btnAgregar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val apellido = etApellido.text.toString()
            val dni = etDni.text.toString()
            val edad = etEdad.text.toString()
            val curso = etCurso.text.toString()
            dataManager.addName(nombre,apellido,dni,edad,curso)
            Toast.makeText(this, "Se agregó a la base de datos: $nombre",
                Toast.LENGTH_SHORT).show()
            etNombre.text.clear()
            etApellido.text.clear()//limpiamos el compononente editext
            etDni.text.clear()//limpiamos el compononente editext
            etEdad.text.clear()//limpiamos el compononente editext
            etCurso.text.clear()//limpiamos el compononente editext
        }
// muestra todos los datos
        btnMostrar.setOnClickListener {
// estamos instanciando la clase datamanager
            val nombres = dataManager.getAllNames(this)
            tvMuestraNombre.text = nombres //nos muestra los nombres que hay en la tabla
        }

        btnEliminar.setOnClickListener {
            val nombre = etNombre.text.toString()
            dataManager.eliminarUser(nombre)
        }

        btnActualizar.setOnClickListener {
            val nombre = etNombre.text.toString()
            dataManager.actualizarUser(nombre)
        }
    }
}