package com.example.ejercicio7.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import com.example.ejercicio7.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnStart = findViewById<AppCompatButton>(R.id.btnStart)
        val etName = findViewById<AppCompatEditText>(R.id.etName)
        val etApellido = findViewById<AppCompatEditText>(R.id.etApellido)
        val etCurso = findViewById<AppCompatEditText>(R.id.etCurso)
        val etAsignatura = findViewById<AppCompatEditText>(R.id.etAsignatura)
        val etNota = findViewById<AppCompatEditText>(R.id.etNota)
        btnStart.setOnClickListener {
            val name = etName.text.toString()
            val apellido = etApellido.text.toString()
            val curso = etCurso.text.toString()
            val asignatura = etAsignatura.text.toString()
            val notas = etNota.text.toString()
            if (name.isNotEmpty()&&apellido.isNotEmpty()&&curso.isNotEmpty()&&
                asignatura.isNotEmpty() && notas.isNotEmpty()) {
                val intent = Intent(this, Result::class.java)
                intent.putExtra("EXTRA_NAME", name)
                intent.putExtra("EXTRA_APELLIDO", apellido)
                intent.putExtra("EXTRA_curso", curso)
                intent.putExtra("EXTRA_asignatura", asignatura)
                intent.putExtra("EXTRA_notas", notas)
                startActivity(intent)
            }
        }
    }
}