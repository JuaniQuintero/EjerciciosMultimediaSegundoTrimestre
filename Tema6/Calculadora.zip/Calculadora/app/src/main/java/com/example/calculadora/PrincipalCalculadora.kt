package com.example.calculadora

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText

class PrincipalCalculadora : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal_calculadora)

        val btnSumar = findViewById<AppCompatButton>(R.id.btnSumar)
        val btnRestar = findViewById<AppCompatButton>(R.id.btnRestar)
        val btnMultiplicar = findViewById<AppCompatButton>(R.id.btnMultiplicar)
        val btnDividir = findViewById<AppCompatButton>(R.id.btnDividir)

        val operador1 = findViewById<AppCompatEditText>(R.id.etoperador1)
        val operador2 = findViewById<AppCompatEditText>(R.id.etoperador2)

        btnSumar.setOnClickListener {
            val num1 = operador1.text.toString()
            val num2 = operador2.text.toString()
            if(num1.isNotEmpty() && num2.isNotEmpty()){
                val resultado:Double = num1.toDouble() + num2.toDouble()
                val intent = Intent(this, Calculadora::class.java)
                intent.putExtra("EXTRA_RESULTADO", resultado)
                startActivity(intent)
            }
        }

        btnRestar.setOnClickListener{
            val num1 = operador1.text.toString()
            val num2 = operador2.text.toString()

            if(num1.isNotEmpty() && num2.isNotEmpty()){
                val resultado:Double = num1.toDouble() - num2.toDouble()
                val intent = Intent(this, Calculadora::class.java)
                intent.putExtra("EXTRA_RESULTADO", resultado)
                startActivity(intent)
            }
        }


        btnMultiplicar.setOnClickListener {
            val num1 = operador1.text.toString()
            val num2 = operador2.text.toString()

            if(num1.isNotEmpty() && num2.isNotEmpty() && !num1.equals("0") && num2.equals("0")){
                val resultado:Double = num1.toDouble() * num2.toDouble()
                val intent = Intent(this, Calculadora::class.java)
                intent.putExtra("EXTRA_RESULTADO", resultado)
                startActivity(intent)
            }
        }

        btnDividir.setOnClickListener {
            val num1 = operador1.text.toString()
            val num2 = operador2.text.toString()

            if(num1.isNotEmpty() && num2.isNotEmpty()){
                val resultado:Double = num1.toDouble() / num2.toDouble()
                val intent = Intent(this, Calculadora::class.java)
                intent.putExtra("EXTRA_RESULTADO", resultado)
                startActivity(intent)
            }
        }
    }
}